﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp5._7._3
{
    public partial class frmParametricFuntion : Form
    {
        private CParametric ObjectCParametric = new CParametric();

        public frmParametricFuntion()
        {
            InitializeComponent();
        }

        private void frmParametricFuntion_Load(object sender, EventArgs e)
        {
            ObjectCParametric.InitializeData();
            ObjectCParametric.InitializeControls(picCanvas, lstX, lstY, lstXp, lstYp);
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            ObjectCParametric.DrawAxis(picCanvas);
            ObjectCParametric.DrawCurve(picCanvas, lstX, lstY, lstXp, lstYp);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ObjectCParametric.InitializeData();
            ObjectCParametric.InitializeControls(picCanvas, lstX, lstY, lstXp, lstYp);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
