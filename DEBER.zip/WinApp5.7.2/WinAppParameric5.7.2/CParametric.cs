﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace WinAppParameric5._7._2
{
    class CParametric
    {
        private Graphics mGraph;
        private const float SF = 20;
        private Pen ObjPen;
        private PointF[] mP = new PointF[21];
        private float mX, mY;
        private float mXp, mYp;
        private float I1, I2;

        public CParametric()
        {
            mX = 0.0f; mY = 0.0f; mXp = 0.0f; mYp = 0.0f;
        }


        // Función para graficar los ejes coordenados.
        public void DrawAxis(PictureBox picCanvas)
        {
            mGraph = picCanvas.CreateGraphics();
            ObjPen = new Pen(Color.Black);
            // Eje horizontal.
            mGraph.DrawLine(ObjPen, 0, 150, 400, 150);
            // Eje vertical.
            mGraph.DrawLine(ObjPen, 200, 0, 200, 300);
        }

        //Función para evaluar la función cuadrática.
        public void EvaluateFunction(ListBox lstX, ListBox lstY, ListBox lstXp, ListBox lstYp)
        {
            float i; // Contador para controlar la función.
            int j;   // Contador para controlar el arreglo de puntos.
            I1 = -10; I2 = 10;
            for (i = I1, j = 0; i <= I2; i++, j++)
            {
                // Tabal de valores del mundo real.
                mX = i; lstX.Items.Add(mX.ToString());
                mY = (3 * mX - 7) / 2.0f; lstY.Items.Add(mY.ToString());
                // Tabla de valores del mundo de la computación gráfica.
                mXp = (float)(mX * SF + 200); lstXp.Items.Add(mXp.ToString());
                mYp = (float)((-1) * mY * SF + 150); lstYp.Items.Add(mYp.ToString());
                // Arreglo de puntos de  tipo flotante.
                mP[j] = new PointF(mXp, mYp);
            }
        }

        // Función para graficar la curva.
        public void DrawCurve(PictureBox picCanvas, ListBox lstX, ListBox lstY, ListBox lstXp, ListBox lstYp)
        {
            mGraph = picCanvas.CreateGraphics();
            ObjPen = new Pen(Color.Blue);
            mP = new PointF[21];

            EvaluateFunction(lstX, lstY, lstXp, lstYp);

            mGraph.DrawCurve(ObjPen, mP);
        }

        public void InitializeData()
        {
            mX = 0.0f; mY = 0.0f; mXp = 0.0f; mYp = 0.0f;
        }

        public void InitializeControls(PictureBox picCanvas, ListBox lstX, ListBox lstY, ListBox lstXp, ListBox lstYp)
        {
            picCanvas.Refresh();
            lstX.Items.Clear(); lstY.Items.Clear(); lstXp.Items.Clear(); lstYp.Items.Clear();
        }
    }
}
